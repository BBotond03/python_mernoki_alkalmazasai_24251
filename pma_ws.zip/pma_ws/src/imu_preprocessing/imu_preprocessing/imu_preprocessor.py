import rclpy
from rclpy.node import Node

class IMUPreprocessor(Node):
    
    def __init__(self):
        super().__init__('imu_preprocessor')
        


        

def main(args=None):
    rclpy.init(args=args)
    
    imu_preprocessor = IMUPreprocessor()

    rclpy.spin(imu_preprocessor)


    imu_preprocessor.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
