import os.path
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node


def generate_launch_description():
    ld = LaunchDescription()

    imu_preprocessing_node = Node(
        package='imu_preprocessing',
        executable='imu_preprocessor'
    )

    play_bag = ExecuteProcess(
        cmd=["ros2", "bag", "play", os.path.join(get_package_share_directory('imu_preprocessing'), 'bags', 'imu_bag.db3')],
        output='screen'
    )

    ld.add_action(play_bag)
    ld.add_action(imu_preprocessing_node)

    return ld